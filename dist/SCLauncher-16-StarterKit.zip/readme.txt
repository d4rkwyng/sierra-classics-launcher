This is a starter kit for Sierra Classics Launcher

It includes 3 Space Quest games:
Space Quest I VGA Remake
Space Quest II
Space Quest III


-Derek Wood