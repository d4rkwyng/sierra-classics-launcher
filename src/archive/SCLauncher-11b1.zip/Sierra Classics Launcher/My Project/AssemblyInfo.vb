﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Sierra Classics Launcher")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Vaguesoft")> 
<Assembly: AssemblyProduct("Sierra Classics Launcher")> 
<Assembly: AssemblyCopyright("Copyright © Vaguesoft 2007")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("194bbfaf-afcb-4365-8818-56f43d1a5d3b")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.11")> 
<Assembly: AssemblyFileVersion("1.0.0.11")> 
