Public NotInheritable Class frmAbout

    Private Sub frmAbout_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set the title of the form.
        Dim ApplicationTitle As String
        If My.Application.Info.Title <> "" Then
            ApplicationTitle = My.Application.Info.Title
        Else
            ApplicationTitle = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
        End If
        Me.Text = String.Format("About {0}", ApplicationTitle)
        ' Initialize all of the text displayed on the About Box.
        ' TODO: Customize the application's assembly information in the "Application" pane of the project 
        '    properties dialog (under the "Project" menu).
        Me.LabelProductName.Text = My.Application.Info.ProductName
        Me.LabelVersion.Text = String.Format("Version {0} Beta", My.Application.Info.Version.ToString)
        Me.LabelCopyright.Text = My.Application.Info.Copyright
        Me.LabelCompanyName.Text = My.Application.Info.CompanyName
        Me.TextBoxDescription.Text = "This program was designed and based off the original Sierra Launcher included with the " & _
        "Sierra Classic Collections.  The intention of this program was to bring back the launcher capability " & _
        "to users affected by the patch created by the Collector.  The program loads shortcuts via specified directories and nothing more.  " & _
        "This program is based off my own code and can be freely distributed. " & _
        ControlChars.NewLine & ControlChars.NewLine & _
        "� 1986-1995 Sierra Entertainment, Inc.  All rights reserved.  Space Quest is a registered trademark of The Children�s Museum of Indianapolis.  " & _
        "Sierra and the Sierra logo are registered trademarks or trademarks of Sierra Entertainment, Inc., in the U.S. and/or other countries."
    End Sub

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        Me.Close()
    End Sub
End Class
