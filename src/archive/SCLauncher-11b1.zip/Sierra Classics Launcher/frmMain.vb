'Sierra Classics Launcher
'Author: Derek Wood
'Created: 2 June 2007

Imports System.IO

Public Class frmMain
    Private Sub btnGame1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGame1.Click
        LaunchProcess(strGameProg(0).ToString, strGamePath(0).ToString, strGameExe(0).ToString, strGameCmd(0).ToString)
    End Sub

    Private Sub btnGame2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGame2.Click
        LaunchProcess(strGameProg(1).ToString, strGamePath(1).ToString, strGameExe(1).ToString, strGameCmd(1).ToString)
    End Sub

    Private Sub btnGame3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGame3.Click
        LaunchProcess(strGameProg(2).ToString, strGamePath(2).ToString, strGameExe(2).ToString, strGameCmd(2).ToString)
    End Sub

    Private Sub btnGame4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGame4.Click
        LaunchProcess(strGameProg(3).ToString, strGamePath(3).ToString, strGameExe(3).ToString, strGameCmd(3).ToString)
    End Sub

    Private Sub btnGame5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGame5.Click
        LaunchProcess(strGameProg(4).ToString, strGamePath(4).ToString, strGameExe(4).ToString, strGameCmd(4).ToString)
    End Sub

    Private Sub btnGame6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGame6.Click
        LaunchProcess(strGameProg(5).ToString, strGamePath(5).ToString, strGameExe(5).ToString, strGameCmd(5).ToString)
    End Sub

    Private Sub btnGame7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGame7.Click
        LaunchProcess(strGameProg(6).ToString, strGamePath(6).ToString, strGameExe(6).ToString, strGameCmd(6).ToString)
    End Sub

    Private Sub btnViewManual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnViewManual.Click
        LaunchProcess("manual", strManual, "", "", False)
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MainLoad()
        SetInformation()
    End Sub

    Private Sub MainLoad()
        Dim strPath As String = Application.StartupPath & "\XML\"
        Dim tmpKey As String = GetRegKey("StartupDatabase")
        Dim rand As New Random

        If LoadFiles(strPath) = True Then
            Select Case LCase(tmpKey)
                Case "first"
                    LoadXMLData(strPath & cboDatabase.Items.Item(0).ToString)
                    cboDatabase.SelectedIndex = 0
                Case "last"
                    LoadXMLData(strPath & cboDatabase.Items.Item(cboDatabase.Items.Count - 1).ToString)
                    cboDatabase.SelectedIndex = cboDatabase.Items.Count - 1
                Case "random"
                    Dim intIndex As Integer
                    intIndex = rand.Next(cboDatabase.Items.Count)
                    LoadXMLData(strPath & cboDatabase.Items.Item(intIndex).ToString)
                    cboDatabase.SelectedIndex = intIndex
                Case Else
                    If InStr(tmpKey, ".xml") Then
                        If File.Exists(strPath & tmpKey) Then
                            LoadXMLData(strPath & tmpKey)
                            cboDatabase.SelectedIndex = cboDatabase.FindString(tmpKey)
                        Else
                            LoadXMLData(strPath & cboDatabase.Items.Item(0).ToString)
                            cboDatabase.SelectedIndex = 0
                        End If
                    Else
                        LoadXMLData(strPath & cboDatabase.Items.Item(0).ToString)
                        cboDatabase.SelectedIndex = 0
                    End If
            End Select
        Else
            MessageBox.Show("No XML files were found. (" & strPath & ")", "No Data Information")
        End If
    End Sub

    Private Function LoadFiles(ByVal strPath As String) As Boolean
        Try
            Dim i As Integer
            Dim DirInfo As New IO.DirectoryInfo(strPath)
            Dim dirFiles As IO.FileInfo() = DirInfo.GetFiles()
            Dim File As IO.FileInfo
            cboDatabase.Items.Clear()

            For Each File In dirFiles

                'strFile(i) = File.ToString

                If InStr(File.ToString, ".xml") Then
                    cboDatabase.Items.Add(File)
                End If

                i += 1
            Next

            If i > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            'MessageBox.Show(ex.Message, "Error")
        End Try
    End Function

    Private Sub SetInformation()
        Try
            grpGame1.Visible = False
            grpGame2.Visible = False
            grpGame3.Visible = False
            grpGame4.Visible = False
            grpGame5.Visible = False
            grpGame6.Visible = False
            grpGame7.Visible = False

            If intGameCount >= 0 Then
                grpGame1.Text = strGameName(0).ToString
                grpGame1.Visible = True
            End If
            If intGameCount > 1 Then
                grpGame2.Text = strGameName(1).ToString
                grpGame2.Visible = True
            End If
            If intGameCount > 2 Then
                grpGame3.Text = strGameName(2).ToString
                grpGame3.Visible = True
            End If
            If intGameCount > 3 Then
                grpGame4.Text = strGameName(3).ToString
                grpGame4.Visible = True
            End If
            If intGameCount > 4 Then
                grpGame5.Text = strGameName(4).ToString
                grpGame5.Visible = True
            End If
            If intGameCount > 5 Then
                grpGame6.Text = strGameName(5).ToString
                grpGame6.Visible = True
            End If
            If intGameCount > 6 Then
                grpGame7.Text = strGameName(6).ToString
                grpGame7.Visible = True
            End If

            If strManual = "" Then
                btnViewManual.Enabled = False
            Else
                btnViewManual.Enabled = True
            End If

            Dim ApplicationTitle As String
            If My.Application.Info.Title <> "" Then
                ApplicationTitle = My.Application.Info.Title
            Else
                ApplicationTitle = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
            End If
            Me.Text = String.Format("{0} - {1}", ApplicationTitle, strGame)
            Me.picGame.ImageLocation = strGameArt
        Catch ex As Exception
            MessageBox.Show(ex.Message & "Error loading content data.  Check your XML files.", "Error")
        End Try
    End Sub

    Private Sub mnuFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpAbout.Click
        frmAbout.Show()
    End Sub

    Private Sub cboDatabase_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDatabase.SelectedIndexChanged
        Dim strPath As String = Application.StartupPath & "\XML\"
        LoadXMLData(strPath & cboDatabase.Text)
        SetInformation()
    End Sub

    Private Sub mnuToolsPreferences_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsPreferences.Click
        frmPreferences.Show()
    End Sub
End Class