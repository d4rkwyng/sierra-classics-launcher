Imports System.Xml
Imports System.IO

Public Class frmPreferences

    Private strGName() As String
    Private strGProg() As String
    Private strGPath() As String
    Private strGExe() As String
    Private strGCmd() As String
    Private intNum As Integer
    Private intGCount As Integer

    Private Sub frmPreferences_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Initialize()
        ReadRegKeys()
    End Sub

    Private Sub Initialize()
        Dim i As Integer
        For i = 0 To frmMain.cboDatabase.Items.Count - 1
            cboDB.Items.Add(frmMain.cboDatabase.Items.Item(i).ToString)
        Next i

        cboDB.SelectedIndex = cboDB.FindString(frmMain.cboDatabase.Text)

        Dim strPath As String = Application.StartupPath & "\XML\"
        ReadXMLData(strPath & frmMain.cboDatabase.Text)

        lblDatabase.Text = "Database: " & frmMain.cboDatabase.Text
        intNum = 0
        LoadGameInfo()
    End Sub

    Private Sub LoadGameInfo()
        lblGameEntry.Text = "Game " & (intNum + 1) & ": "
        txtGameName.Text = strGName(intNum).ToString
        txtGameProg.Text = strGProg(intNum).ToString
        txtGamePath.Text = strGPath(intNum).ToString
        txtGameExe.Text = strGExe(intNum).ToString
        txtGameCmd.Text = strGCmd(intNum).ToString
    End Sub

    Private Sub SaveGameInfo()
        strGName(intNum) = txtGameName.Text
        strGProg(intNum) = txtGameProg.Text
        strGPath(intNum) = txtGamePath.Text
        strGExe(intNum) = txtGameExe.Text
        strGCmd(intNum) = txtGameCmd.Text
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnGameNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGameNext.Click
        If Not intNum >= (intGCount - 1) Then
            SaveGameInfo()
            intNum += 1
            LoadGameInfo()
        End If
    End Sub

    Private Sub btnGameBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGameBack.Click
        If Not intNum <= 0 Then
            SaveGameInfo()
            intNum -= 1
            LoadGameInfo()
        End If
    End Sub

    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen.Click
        If Not cboDB.Text = "" Then
            Dim strPath As String = Application.StartupPath & "\XML\"
            ReadXMLData(strPath & cboDB.Text)
        End If
        intNum = 0
        lblDatabase.Text = "Database: " & cboDB.Text
        LoadGameInfo()
    End Sub

    Private Sub ReadXMLData(ByVal strXMLFile As String)
        Try
            Dim Doc As New XmlDocument
            Dim Input As New XmlTextReader(strXMLFile)
            Input.WhitespaceHandling = WhitespaceHandling.None
            If File.Exists(strXMLFile) Then
                Do While Input.Read()
                    If Input.NodeType = XmlNodeType.Element Then
                        Select Case Input.Name
                            Case "Name"
                                txtName.Text = Input.ReadString()
                            Case "NumButtons"
                                intGCount = Input.ReadString()
                                txtNumButtons.Text = intGCount
                                ReDim strGName(intGCount)
                                ReDim strGProg(intGCount)
                                ReDim strGPath(intGCount)
                                ReDim strGExe(intGCount)
                                ReDim strGCmd(intGCount)

                                ' initialize variables (precaution)
                                Dim x As Integer
                                For x = 0 To intGCount - 1
                                    strGName(x) = ""
                                    strGProg(x) = ""
                                    strGPath(x) = ""
                                    strGExe(x) = ""
                                    strGCmd(x) = ""
                                Next x
                            Case "DefaultPath"
                                txtDefaultPath.Text = Input.ReadString
                            Case "GameManual"
                                txtManual.Text = Input.ReadString
                            Case "GameArt"
                                txtArt.Text = Input.ReadString

                                '
                                ' Possible Loop to Shorten Code
                                '

                            Case "Game1Name"
                                strGName(0) = Input.ReadString()
                            Case "Game1Prog"
                                strGProg(0) = Input.ReadString()
                            Case "Game1Path"
                                strGPath(0) = Input.ReadString()
                            Case "Game1Exe"
                                strGExe(0) = Input.ReadString()
                            Case "Game1Cmd"
                                strGCmd(0) = Input.ReadString()

                            Case "Game2Name"
                                strGName(1) = Input.ReadString()
                            Case "Game2Prog"
                                strGProg(1) = Input.ReadString()
                            Case "Game2Path"
                                strGPath(1) = Input.ReadString()
                            Case "Game2Exe"
                                strGExe(1) = Input.ReadString()
                            Case "Game2Cmd"
                                strGCmd(1) = Input.ReadString()

                            Case "Game3Name"
                                strGName(2) = Input.ReadString()
                            Case "Game3Prog"
                                strGProg(2) = Input.ReadString()
                            Case "Game3Path"
                                strGPath(2) = Input.ReadString()
                            Case "Game3Exe"
                                strGExe(2) = Input.ReadString()
                            Case "Game3Cmd"
                                strGCmd(2) = Input.ReadString()

                            Case "Game4Name"
                                strGName(3) = Input.ReadString()
                            Case "Game4Prog"
                                strGProg(3) = Input.ReadString()
                            Case "Game4Path"
                                strGPath(3) = Input.ReadString()
                            Case "Game4Exe"
                                strGExe(3) = Input.ReadString()
                            Case "Game4Cmd"
                                strGCmd(3) = Input.ReadString()

                            Case "Game5Name"
                                strGName(4) = Input.ReadString()
                            Case "Game5Prog"
                                strGProg(4) = Input.ReadString()
                            Case "Game5Path"
                                strGPath(4) = Input.ReadString()
                            Case "Game5Exe"
                                strGExe(4) = Input.ReadString()
                            Case "Game5Cmd"
                                strGCmd(4) = Input.ReadString()

                            Case "Game6Name"
                                strGName(5) = Input.ReadString()
                            Case "Game6Prog"
                                strGProg(5) = Input.ReadString()
                            Case "Game6Path"
                                strGPath(5) = Input.ReadString()
                            Case "Game6Exe"
                                strGExe(5) = Input.ReadString()
                            Case "Game6Cmd"
                                strGCmd(5) = Input.ReadString()

                            Case "Game7Name"
                                strGName(6) = Input.ReadString()
                            Case "Game7Prog"
                                strGProg(6) = Input.ReadString()
                            Case "Game7Path"
                                strGPath(6) = Input.ReadString()
                            Case "Game7Exe"
                                strGExe(6) = Input.ReadString()
                            Case "Game7Cmd"
                                strGCmd(6) = Input.ReadString()
                        End Select
                    End If
                Loop
                Input.Close()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub

    Private Sub SaveRegKeys()
        Dim tmpKey As String
        tmpKey = GetRegKey("StartupDatabase")
        If (LCase(cboAutoLoadDB.Text) = "custom") Then
            SetRegKey("StartupDatabase", txtAutoLoadCustom.Text)
        Else
            SetRegKey("StartupDatabase", cboAutoLoadDB.Text)
        End If
        SetRegKey("dosbox", txtDOSBox.Text)
    End Sub

    Private Sub ReadRegKeys()
        Dim tmpKey As String
        tmpKey = GetRegKey("StartupDatabase")
        If InStr(tmpKey, ".xml") Then
            cboAutoLoadDB.Text = "Custom"
            txtAutoLoadCustom.Text = tmpKey
        Else
            cboAutoLoadDB.Text = tmpKey
        End If
        txtDOSBox.Text = GetRegKey("dosbox")
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        SaveGameInfo()
        SaveRegKeys()
        Dim strPath As String = Application.StartupPath & "\XML\"
        SaveXMLData(strPath & cboDB.Text)
    End Sub

    Private Sub cboAutoLoadDB_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboAutoLoadDB.SelectedIndexChanged
        If LCase(cboAutoLoadDB.Text) = "custom" Then
            txtAutoLoadCustom.Visible = True
        Else
            txtAutoLoadCustom.Visible = False
        End If
    End Sub

    Private Sub SaveXMLData(ByVal strXMLFile As String)
        Try
            ' Write XML Data 
            Dim Doc As New XmlDocument
            Doc.PreserveWhitespace = True

            'Create a 'vanilla' XML Declaration (processing instruction)
            Dim myXmlDeclaration As XmlDeclaration
            myXmlDeclaration = _
                Doc.CreateXmlDeclaration("1.0", Nothing, Nothing)
            Doc.AppendChild(myXmlDeclaration)
            '                           <-Root Created

            Dim Root As XmlElement


            Root = Doc.CreateElement(Mid(cboDB.Text, 1, cboDB.Text.Length - 4))


            ' Collection Name
            Dim Child As XmlElement
            Child = Doc.CreateElement("Name")
            Child.InnerText = txtName.Text
            'Need a comment in article about not being able to use Value
            Root.AppendChild(Child)

            ' Num Buttons
            Child = Doc.CreateElement("NumButtons")
            Child.InnerText = txtNumButtons.Text
            Root.AppendChild(Child)

            ' Default Path
            Child = Doc.CreateElement("DefaultPath")
            Child.InnerText = txtDefaultPath.Text
            Root.AppendChild(Child)

            ' Game Manual
            Child = Doc.CreateElement("GameManual")
            Child.InnerText = txtManual.Text
            Root.AppendChild(Child)

            ' Game Art
            Child = Doc.CreateElement("GameArt")
            Child.InnerText = txtArt.Text
            Root.AppendChild(Child)

            ' Loop for writing game content
            Dim i As Integer
            Dim tmpNum As Integer
            tmpNum = intNum
            intNum = 0
            For i = 1 To intGCount
                LoadGameInfo()

                Child = Doc.CreateElement("Game" & i & "Name")
                Child.InnerText = txtGameName.Text
                Root.AppendChild(Child)

                Child = Doc.CreateElement("Game" & i & "Prog")
                Child.InnerText = txtGameProg.Text
                Root.AppendChild(Child)

                Child = Doc.CreateElement("Game" & i & "Path")
                Child.InnerText = txtGamePath.Text
                Root.AppendChild(Child)

                Child = Doc.CreateElement("Game" & i & "Exe")
                Child.InnerText = txtGameExe.Text
                Root.AppendChild(Child)

                Child = Doc.CreateElement("Game" & i & "Cmd")
                Child.InnerText = txtGameCmd.Text
                Root.AppendChild(Child)

                intNum += 1
            Next i

            intNum = tmpNum
            LoadGameInfo()

            Doc.AppendChild(Root)

            'Write XML to a file
            Dim Output As New XmlTextWriter(strXMLFile, System.Text.Encoding.UTF8)
            Doc.WriteTo(Output)
            Output.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Dim strNewName As String
        strNewName = InputBox("Enter new database name: ", "New")

        If Not strNewName = "" Then
            lblDatabase.Text = "Database: " & strNewName
            cboDB.Text = strNewName
            txtName.Clear()
            txtNumButtons.Clear()
            txtDefaultPath.Clear()
            txtManual.Clear()
            txtArt.Clear()

            intGCount = 1
            intNum = 0
            ReDim strGName(intGCount)
            ReDim strGProg(intGCount)
            ReDim strGPath(intGCount)
            ReDim strGExe(intGCount)
            ReDim strGCmd(intGCount)

            ' initialize variables (precaution)
            Dim x As Integer
            For x = 0 To intGCount - 1
                strGName(x) = ""
                strGProg(x) = ""
                strGPath(x) = ""
                strGExe(x) = ""
                strGCmd(x) = ""
            Next x

            LoadGameInfo()
        End If
    End Sub

    Private Sub txtNumButtons_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNumButtons.TextChanged
        If (txtNumButtons.Text = "") Then
            Return
        End If

        If Not IsNumeric(txtNumButtons.Text) Then
            MessageBox.Show("Must be a numeric value.")
            Return
        End If

        If (CInt(txtNumButtons.Text) <= 0) Then
            MessageBox.Show("Must be a number greater than 0.")
            Return
        End If

        If (CInt(txtNumButtons.Text) > 7) Then
            MessageBox.Show("Must be a number less than or equal to 7.")
            Return
        End If

        If txtNumButtons.Text = "" Then
            intGCount = 0
        Else
            intGCount = CInt(txtNumButtons.Text)
            intNum = 0
            ReDim strGName(intGCount)
            ReDim strGProg(intGCount)
            ReDim strGPath(intGCount)
            ReDim strGExe(intGCount)
            ReDim strGCmd(intGCount)

            ' initialize variables (precaution)
            Dim x As Integer
            For x = 0 To intGCount - 1
                strGName(x) = ""
                strGProg(x) = ""
                strGPath(x) = ""
                strGExe(x) = ""
                strGCmd(x) = ""
            Next x
        End If
    End Sub
End Class