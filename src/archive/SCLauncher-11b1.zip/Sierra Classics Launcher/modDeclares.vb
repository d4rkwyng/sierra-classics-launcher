Module modDeclares
    Public strFile() As String
    Public strGame As String
    Public strGameArt As String
    Public strManual As String
    Public strDefaultPath As String

    Public intGameCount As Integer
    Public strGameName() As String
    Public strGameProg() As String
    Public strGamePath() As String
    Public strGameExe() As String
    Public strGameCmd() As String
End Module
