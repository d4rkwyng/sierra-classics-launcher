Imports Microsoft.Win32
Imports System.Xml
Imports System.IO

Module modFunctions
    Public Sub LoadXMLData(ByVal strXMLFile As String)
        Try
            Dim Input As New XmlTextReader(strXMLFile)
            Input.WhitespaceHandling = WhitespaceHandling.None
            If File.Exists(strXMLFile) Then
                Do While Input.Read()
                    If Input.NodeType = XmlNodeType.Element Then
                        Select Case Input.Name
                            Case "Name"
                                strGame = Input.ReadString()
                            Case "NumButtons"
                                intGameCount = Input.ReadString()
                                ReDim strGameName(intGameCount)
                                ReDim strGameProg(intGameCount)
                                ReDim strGamePath(intGameCount)
                                ReDim strGameExe(intGameCount)
                                ReDim strGameCmd(intGameCount)

                                ' initialize variables (precaution)
                                Dim x As Integer
                                For x = 0 To intGameCount
                                    strGameName(x) = ""
                                    strGameProg(x) = ""
                                    strGamePath(x) = ""
                                    strGameExe(x) = ""
                                    strGameCmd(x) = ""
                                Next x
                            Case "DefaultPath"
                                strDefaultPath = Input.ReadString
                            Case "GameManual"
                                strManual = Input.ReadString()
                            Case "GameArt"
                                strGameArt = Input.ReadString()

                                '
                                ' Possible Loop to Shorten Code
                                '

                            Case "Game1Name"
                                strGameName(0) = Input.ReadString()
                            Case "Game1Prog"
                                strGameProg(0) = Input.ReadString()
                            Case "Game1Path"
                                strGamePath(0) = Input.ReadString()
                            Case "Game1Exe"
                                strGameExe(0) = Input.ReadString()
                            Case "Game1Cmd"
                                strGameCmd(0) = Input.ReadString()

                            Case "Game2Name"
                                strGameName(1) = Input.ReadString()
                            Case "Game2Prog"
                                strGameProg(1) = Input.ReadString()
                            Case "Game2Path"
                                strGamePath(1) = Input.ReadString()
                            Case "Game2Exe"
                                strGameExe(1) = Input.ReadString()
                            Case "Game2Cmd"
                                strGameCmd(1) = Input.ReadString()

                            Case "Game3Name"
                                strGameName(2) = Input.ReadString()
                            Case "Game3Prog"
                                strGameProg(2) = Input.ReadString()
                            Case "Game3Path"
                                strGamePath(2) = Input.ReadString()
                            Case "Game3Exe"
                                strGameExe(2) = Input.ReadString()
                            Case "Game3Cmd"
                                strGameCmd(2) = Input.ReadString()

                            Case "Game4Name"
                                strGameName(3) = Input.ReadString()
                            Case "Game4Prog"
                                strGameProg(3) = Input.ReadString()
                            Case "Game4Path"
                                strGamePath(3) = Input.ReadString()
                            Case "Game4Exe"
                                strGameExe(3) = Input.ReadString()
                            Case "Game4Cmd"
                                strGameCmd(3) = Input.ReadString()

                            Case "Game5Name"
                                strGameName(4) = Input.ReadString()
                            Case "Game5Prog"
                                strGameProg(4) = Input.ReadString()
                            Case "Game5Path"
                                strGamePath(4) = Input.ReadString()
                            Case "Game5Exe"
                                strGameExe(4) = Input.ReadString()
                            Case "Game5Cmd"
                                strGameCmd(4) = Input.ReadString()

                            Case "Game6Name"
                                strGameName(5) = Input.ReadString()
                            Case "Game6Prog"
                                strGameProg(5) = Input.ReadString()
                            Case "Game6Path"
                                strGamePath(5) = Input.ReadString()
                            Case "Game6Exe"
                                strGameExe(5) = Input.ReadString()
                            Case "Game6Cmd"
                                strGameCmd(5) = Input.ReadString()

                            Case "Game7Name"
                                strGameName(6) = Input.ReadString()
                            Case "Game7Prog"
                                strGameProg(6) = Input.ReadString()
                            Case "Game7Path"
                                strGamePath(6) = Input.ReadString()
                            Case "Game7Exe"
                                strGameExe(6) = Input.ReadString()
                            Case "Game7Cmd"
                                strGameCmd(6) = Input.ReadString()
                        End Select
                    End If
                Loop
            End If

            Input.Close()

            Dim i As Integer
            For i = 0 To intGameCount
                If InStr(LCase(strGamePath(i)), "%path") Then
                    strGamePath(i) = Replace(strGamePath(i).ToString, "%PATH", strDefaultPath)
                End If

                If InStr(LCase(strManual), "%path") Then
                    strManual = Replace(strManual, "%PATH", strDefaultPath)
                End If

                If InStr(LCase(strGameArt), "%path") Then
                    strGameArt = Replace(strGameArt, "%PATH", strDefaultPath)
                End If

                If InStr(LCase(strGameCmd(i)), "%path") Then
                    strGameCmd(i) = Replace(strGameCmd(i).ToString, "%PATH", strDefaultPath)
                End If
            Next i
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub

    Public Sub LaunchProcess(ByVal strProg As String, ByVal strPath As String, ByVal strExe As String, ByVal strCmd As String, _
    Optional ByVal check As Boolean = True)
        Try
            If InStr(strPath, ".lnk") Then
                Diagnostics.Process.Start(strPath)
            Else
                If Mid(strPath, strPath.Length) = "\" Then ' checks to see if there is a trailing \ slash
                    strPath = Mid(strPath, 1, strPath.Length - 1)
                End If


                If strProg = "manual" Then
                    Diagnostics.Process.Start(strPath)
                    Return
                End If

                Dim strTempProg As String
                strTempProg = GetRegKey(strProg)

                If strProg = "dosbox" Then
                    If Not Mid(strTempProg, strTempProg.Length) = "\" Then
                        strTempProg &= "\"
                    End If
                    strTempProg &= "dosbox.exe"
                End If

                If strProg = "" Then
                    Shell(strPath & "\" & strExe & """ " & strCmd)
                Else
                    Shell(strTempProg & " """ & strPath & "\" & strExe & """ " & strCmd)
                End If

                'Dim strTempPath As String

                'strTempPath = "-c ""mount c """ & strPath & """""" & " -c ""C:""" & " -c """ & strExe & " " & strCmd & """"
                'Shell(strTempProg & " " & strTempPath)
                ' mount C strPath
                ' C:
                ' strExe



            End If

            If check = True Then
                CheckToClose()
            End If
        Catch ex As Exception
            'MessageBox.Show("""" & path & """ could not be found.", "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error)
            MessageBox.Show(ex.Message, "Launch Error")
        End Try
    End Sub

    Private Sub CheckToClose()
        If frmMain.chkCloseWindow.Checked = True Then
            frmMain.Close()
        End If
    End Sub

    Public Function GetRegKey(ByVal strKey As String) As String
        Try
            Dim strKeyLoc As String = "Software\Vaguesoft\Sierra Classics Launcher\Settings"
            Dim regPaths As RegistryKey
            regPaths = Registry.LocalMachine.OpenSubKey(strKeyLoc, True)

            ' Create key if it doesn't exist
            If regPaths Is Nothing Then
                regPaths = Registry.LocalMachine.CreateSubKey(strKeyLoc)
            End If

            If (regPaths.GetValue(strKey) Is Nothing) And (strKey = "dosbox") Then
                regPaths.SetValue(strKey, "C:\Program Files\DOSBox-0.70\dosbox.exe")
            End If

            Dim tempKey As String = regPaths.GetValue(strKey)
            regPaths.Close()
            If tempKey = Nothing Then
                Return ""
            Else
                Return tempKey
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Public Sub SetRegKey(ByVal strKey As String, ByVal strValue As String)
        Try
            Dim strKeyLoc As String = "Software\Vaguesoft\Sierra Classics Launcher\Settings"
            Dim regPaths As RegistryKey
            regPaths = Registry.LocalMachine.OpenSubKey(strKeyLoc, True)

            ' Create key if it doesn't exist
            If regPaths Is Nothing Then
                regPaths = Registry.LocalMachine.CreateSubKey(strKeyLoc)
            End If

            regPaths.SetValue(strKey, strValue)
            regPaths.Close()
        Catch ex As Exception

        End Try
    End Sub
End Module
